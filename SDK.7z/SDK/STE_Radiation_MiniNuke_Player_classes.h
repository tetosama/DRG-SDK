#pragma once

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass STE_Radiation_MiniNuke_Player.STE_Radiation_MiniNuke_Player_C
// 0x0000 (0x00E8 - 0x00E8)
class USTE_Radiation_MiniNuke_Player_C : public UStatusEffect
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass STE_Radiation_MiniNuke_Player.STE_Radiation_MiniNuke_Player_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
