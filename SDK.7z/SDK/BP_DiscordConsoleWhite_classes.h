#pragma once

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_DiscordConsoleWhite.BP_DiscordConsoleWhite_C
// 0x0000 (0x0390 - 0x0390)
class ABP_DiscordConsoleWhite_C : public ABP_DiscordConsole_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_DiscordConsoleWhite.BP_DiscordConsoleWhite_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
