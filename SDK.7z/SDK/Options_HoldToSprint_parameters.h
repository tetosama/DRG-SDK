#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Options_HoldToSprint.Options_HoldToSprint_C.Construct
struct UOptions_HoldToSprint_C_Construct_Params
{
};

// Function Options_HoldToSprint.Options_HoldToSprint_C.UINeedsUpdate
struct UOptions_HoldToSprint_C_UINeedsUpdate_Params
{
};

// Function Options_HoldToSprint.Options_HoldToSprint_C.ShowOptions
struct UOptions_HoldToSprint_C_ShowOptions_Params
{
};

// Function Options_HoldToSprint.Options_HoldToSprint_C.BndEvt__Basic_CheckBox_K2Node_ComponentBoundEvent_8_OnCheckStateChanged__DelegateSignature
struct UOptions_HoldToSprint_C_BndEvt__Basic_CheckBox_K2Node_ComponentBoundEvent_8_OnCheckStateChanged__DelegateSignature_Params
{
	bool*                                              IsChecked;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Options_HoldToSprint.Options_HoldToSprint_C.ExecuteUbergraph_Options_HoldToSprint
struct UOptions_HoldToSprint_C_ExecuteUbergraph_Options_HoldToSprint_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
