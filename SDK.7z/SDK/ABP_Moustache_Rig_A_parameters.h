#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ABP_Moustache_Rig_A.ABP_Moustache_Rig_A_C.ExecuteUbergraph_ABP_Moustache_Rig_A
struct UABP_Moustache_Rig_A_C_ExecuteUbergraph_ABP_Moustache_Rig_A_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
