#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ITM_MisSel_DotMarker_WorkEnvironment.ITM_MisSel_DotMarker_WorkEnvironment_C.PreConstruct
struct UITM_MisSel_DotMarker_WorkEnvironment_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ITM_MisSel_DotMarker_WorkEnvironment.ITM_MisSel_DotMarker_WorkEnvironment_C.SetData
struct UITM_MisSel_DotMarker_WorkEnvironment_C_SetData_Params
{
	class UDifficultySetting**                         Difficulty;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ITM_MisSel_DotMarker_WorkEnvironment.ITM_MisSel_DotMarker_WorkEnvironment_C.ExecuteUbergraph_ITM_MisSel_DotMarker_WorkEnvironment
struct UITM_MisSel_DotMarker_WorkEnvironment_C_ExecuteUbergraph_ITM_MisSel_DotMarker_WorkEnvironment_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
