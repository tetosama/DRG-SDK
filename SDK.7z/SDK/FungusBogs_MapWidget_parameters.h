#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function FungusBogs_MapWidget.FungusBogs_MapWidget_C.GetBasePanel
struct UFungusBogs_MapWidget_C_GetBasePanel_Params
{
	class UCanvasPanel*                                Panel;                                                    // (Parm, OutParm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
