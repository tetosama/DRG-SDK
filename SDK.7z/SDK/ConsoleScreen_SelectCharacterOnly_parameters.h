#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ConsoleScreen_SelectCharacterOnly.ConsoleScreen_SelectCharacterOnly_C.Construct
struct UConsoleScreen_SelectCharacterOnly_C_Construct_Params
{
};

// Function ConsoleScreen_SelectCharacterOnly.ConsoleScreen_SelectCharacterOnly_C.ExecuteUbergraph_ConsoleScreen_SelectCharacterOnly
struct UConsoleScreen_SelectCharacterOnly_C_ExecuteUbergraph_ConsoleScreen_SelectCharacterOnly_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
