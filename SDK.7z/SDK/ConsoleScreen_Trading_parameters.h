#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ConsoleScreen_Trading.ConsoleScreen_Trading_C.Construct
struct UConsoleScreen_Trading_C_Construct_Params
{
};

// Function ConsoleScreen_Trading.ConsoleScreen_Trading_C.ExecuteUbergraph_ConsoleScreen_Trading
struct UConsoleScreen_Trading_C_ExecuteUbergraph_ConsoleScreen_Trading_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
