#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ITM_MissionMapIcon_LevelLock.ITM_MissionMapIcon_LevelLock_C.PreConstruct
struct UITM_MissionMapIcon_LevelLock_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ITM_MissionMapIcon_LevelLock.ITM_MissionMapIcon_LevelLock_C.ExecuteUbergraph_ITM_MissionMapIcon_LevelLock
struct UITM_MissionMapIcon_LevelLock_C_ExecuteUbergraph_ITM_MissionMapIcon_LevelLock_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
