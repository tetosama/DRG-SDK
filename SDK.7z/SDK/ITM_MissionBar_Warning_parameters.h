#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ITM_MissionBar_Warning.ITM_MissionBar_Warning_C.Update
struct UITM_MissionBar_Warning_C_Update_Params
{
	class UGeneratedMission**                          mission;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ITM_MissionBar_Warning.ITM_MissionBar_Warning_C.PreConstruct
struct UITM_MissionBar_Warning_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ITM_MissionBar_Warning.ITM_MissionBar_Warning_C.SetData
struct UITM_MissionBar_Warning_C_SetData_Params
{
	class UGeneratedMission**                          mission;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ITM_MissionBar_Warning.ITM_MissionBar_Warning_C.Construct
struct UITM_MissionBar_Warning_C_Construct_Params
{
};

// Function ITM_MissionBar_Warning.ITM_MissionBar_Warning_C.ExecuteUbergraph_ITM_MissionBar_Warning
struct UITM_MissionBar_Warning_C_ExecuteUbergraph_ITM_MissionBar_Warning_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
