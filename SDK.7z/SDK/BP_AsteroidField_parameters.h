#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_AsteroidField.BP_AsteroidField_C.UserConstructionScript
struct ABP_AsteroidField_C_UserConstructionScript_Params
{
};

// Function BP_AsteroidField.BP_AsteroidField_C.ReceiveBeginPlay
struct ABP_AsteroidField_C_ReceiveBeginPlay_Params
{
};

// Function BP_AsteroidField.BP_AsteroidField_C.ExecuteUbergraph_BP_AsteroidField
struct ABP_AsteroidField_C_ExecuteUbergraph_BP_AsteroidField_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
