#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function UI_RewardResourceAditive.UI_RewardResourceAditive_C.PreConstruct
struct UUI_RewardResourceAditive_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function UI_RewardResourceAditive.UI_RewardResourceAditive_C.ExecuteUbergraph_UI_RewardResourceAditive
struct UUI_RewardResourceAditive_C_ExecuteUbergraph_UI_RewardResourceAditive_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
