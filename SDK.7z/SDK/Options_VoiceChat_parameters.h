#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Options_VoiceChat.Options_VoiceChat_C.Construct
struct UOptions_VoiceChat_C_Construct_Params
{
};

// Function Options_VoiceChat.Options_VoiceChat_C.UINeedsUpdate
struct UOptions_VoiceChat_C_UINeedsUpdate_Params
{
};

// Function Options_VoiceChat.Options_VoiceChat_C.ShowOptions
struct UOptions_VoiceChat_C_ShowOptions_Params
{
};

// Function Options_VoiceChat.Options_VoiceChat_C.BndEvt__Basic_CheckBox_K2Node_ComponentBoundEvent_4_OnCheckStateChanged__DelegateSignature
struct UOptions_VoiceChat_C_BndEvt__Basic_CheckBox_K2Node_ComponentBoundEvent_4_OnCheckStateChanged__DelegateSignature_Params
{
	bool*                                              IsChecked;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Options_VoiceChat.Options_VoiceChat_C.ExecuteUbergraph_Options_VoiceChat
struct UOptions_VoiceChat_C_ExecuteUbergraph_Options_VoiceChat_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
