#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_DropPodScreenActor1.BP_DropPodScreenActor1_C.TriggerCountdown
struct ABP_DropPodScreenActor1_C_TriggerCountdown_Params
{
};

// Function BP_DropPodScreenActor1.BP_DropPodScreenActor1_C.ReceiveTick
struct ABP_DropPodScreenActor1_C_ReceiveTick_Params
{
	float*                                             DeltaSeconds;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BP_DropPodScreenActor1.BP_DropPodScreenActor1_C.ExecuteUbergraph_BP_DropPodScreenActor1
struct ABP_DropPodScreenActor1_C_ExecuteUbergraph_BP_DropPodScreenActor1_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
