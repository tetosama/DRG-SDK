#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Options_Tab_UI.Options_Tab_UI_C.Construct
struct UOptions_Tab_UI_C_Construct_Params
{
};

// Function Options_Tab_UI.Options_Tab_UI_C.BndEvt__Options_Language_K2Node_ComponentBoundEvent_0_OnLanguageChanged__DelegateSignature
struct UOptions_Tab_UI_C_BndEvt__Options_Language_K2Node_ComponentBoundEvent_0_OnLanguageChanged__DelegateSignature_Params
{
	struct FLocalizedLanguageInfo*                     Selected_Language;                                        // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Options_Tab_UI.Options_Tab_UI_C.PreConstruct
struct UOptions_Tab_UI_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Options_Tab_UI.Options_Tab_UI_C.ExecuteUbergraph_Options_Tab_UI
struct UOptions_Tab_UI_C_ExecuteUbergraph_Options_Tab_UI_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Options_Tab_UI.Options_Tab_UI_C.SettingsChanged__DelegateSignature
struct UOptions_Tab_UI_C_SettingsChanged__DelegateSignature_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
