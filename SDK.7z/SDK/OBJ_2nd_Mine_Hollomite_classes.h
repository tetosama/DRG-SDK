#pragma once

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass OBJ_2nd_Mine_Hollomite.OBJ_2nd_Mine_Hollomite_C
// 0x0000 (0x01D0 - 0x01D0)
class UOBJ_2nd_Mine_Hollomite_C : public UOBJ_Resource_Base_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass OBJ_2nd_Mine_Hollomite.OBJ_2nd_Mine_Hollomite_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
