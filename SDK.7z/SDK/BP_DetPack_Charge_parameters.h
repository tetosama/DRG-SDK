#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.OnRep_IsPlaced
struct ABP_DetPack_Charge_C_OnRep_IsPlaced_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.UserConstructionScript
struct ABP_DetPack_Charge_C_UserConstructionScript_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.SphereTimeline__FinishedFunc
struct ABP_DetPack_Charge_C_SphereTimeline__FinishedFunc_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.SphereTimeline__UpdateFunc
struct ABP_DetPack_Charge_C_SphereTimeline__UpdateFunc_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.ReceiveBeginPlay
struct ABP_DetPack_Charge_C_ReceiveBeginPlay_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.RecieveHitObject
struct ABP_DetPack_Charge_C_RecieveHitObject_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.OnExploded
struct ABP_DetPack_Charge_C_OnExploded_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.Show Warning Sphere
struct ABP_DetPack_Charge_C_Show_Warning_Sphere_Params
{
};

// Function BP_DetPack_Charge.BP_DetPack_Charge_C.ExecuteUbergraph_BP_DetPack_Charge
struct ABP_DetPack_Charge_C_ExecuteUbergraph_BP_DetPack_Charge_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
