#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ABP_HeavyDual_Drill_R.ABP_HeavyDual_Drill_R_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_HeavyDual_Drill_R_AnimGraphNode_TransitionResult_390E1F5847CCD80694ADF384F17BEFAF
struct UABP_HeavyDual_Drill_R_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_HeavyDual_Drill_R_AnimGraphNode_TransitionResult_390E1F5847CCD80694ADF384F17BEFAF_Params
{
};

// Function ABP_HeavyDual_Drill_R.ABP_HeavyDual_Drill_R_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_HeavyDual_Drill_R_AnimGraphNode_TransitionResult_D12FE6AB4B7BC9F94D60F68F1B91CF96
struct UABP_HeavyDual_Drill_R_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_HeavyDual_Drill_R_AnimGraphNode_TransitionResult_D12FE6AB4B7BC9F94D60F68F1B91CF96_Params
{
};

// Function ABP_HeavyDual_Drill_R.ABP_HeavyDual_Drill_R_C.ExecuteUbergraph_ABP_HeavyDual_Drill_R
struct UABP_HeavyDual_Drill_R_C_ExecuteUbergraph_ABP_HeavyDual_Drill_R_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
