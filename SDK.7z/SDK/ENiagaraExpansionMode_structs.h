#pragma once

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ENiagaraExpansionMode.ENiagaraExpansionMode
enum class ENiagaraExpansionMode : uint8_t
{
	ENiagaraExpansionMode__NewEnumerator0 = 0,
	ENiagaraExpansionMode__NewEnumerator1 = 1,
	ENiagaraExpansionMode__NewEnumerator2 = 2,
	ENiagaraExpansionMode__ENiagaraExpansionMode_MAX = 3
};



}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
