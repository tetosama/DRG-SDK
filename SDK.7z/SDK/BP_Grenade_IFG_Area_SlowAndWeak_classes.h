#pragma once

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_Grenade_IFG_Area_SlowAndWeak.BP_Grenade_IFG_Area_SlowAndWeak_C
// 0x0000 (0x0369 - 0x0369)
class ABP_Grenade_IFG_Area_SlowAndWeak_C : public ABP_Grenade_IFG_Area_Base_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_Grenade_IFG_Area_SlowAndWeak.BP_Grenade_IFG_Area_SlowAndWeak_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
