#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ITM_ChaCus_ColorChange_ColorBox.ITM_ChaCus_ColorChange_ColorBox_C.Construct
struct UITM_ChaCus_ColorChange_ColorBox_C_Construct_Params
{
};

// Function ITM_ChaCus_ColorChange_ColorBox.ITM_ChaCus_ColorChange_ColorBox_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
struct UITM_ChaCus_ColorChange_ColorBox_C_BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature_Params
{
};

// Function ITM_ChaCus_ColorChange_ColorBox.ITM_ChaCus_ColorChange_ColorBox_C.Unselect
struct UITM_ChaCus_ColorChange_ColorBox_C_Unselect_Params
{
};

// Function ITM_ChaCus_ColorChange_ColorBox.ITM_ChaCus_ColorChange_ColorBox_C.Select
struct UITM_ChaCus_ColorChange_ColorBox_C_Select_Params
{
};

// Function ITM_ChaCus_ColorChange_ColorBox.ITM_ChaCus_ColorChange_ColorBox_C.ApplyColor
struct UITM_ChaCus_ColorChange_ColorBox_C_ApplyColor_Params
{
};

// Function ITM_ChaCus_ColorChange_ColorBox.ITM_ChaCus_ColorChange_ColorBox_C.ExecuteUbergraph_ITM_ChaCus_ColorChange_ColorBox
struct UITM_ChaCus_ColorChange_ColorBox_C_ExecuteUbergraph_ITM_ChaCus_ColorChange_ColorBox_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ITM_ChaCus_ColorChange_ColorBox.ITM_ChaCus_ColorChange_ColorBox_C.Clicked__DelegateSignature
struct UITM_ChaCus_ColorChange_ColorBox_C_Clicked__DelegateSignature_Params
{
	class UITM_ChaCus_ColorChange_ColorBox_C**         Item;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
