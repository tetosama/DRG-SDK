#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.SetHeaderText
struct UBasic_Menu_SmallWindowWithHeader_C_SetHeaderText_Params
{
	struct FText*                                      NewHeaderText;                                            // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.IsHovering
struct UBasic_Menu_SmallWindowWithHeader_C_IsHovering_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature
struct UBasic_Menu_SmallWindowWithHeader_C_BndEvt__Button_0_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature_Params
{
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature
struct UBasic_Menu_SmallWindowWithHeader_C_BndEvt__Button_0_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature_Params
{
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature
struct UBasic_Menu_SmallWindowWithHeader_C_BndEvt__Button_0_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature_Params
{
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.PreConstruct
struct UBasic_Menu_SmallWindowWithHeader_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.SetCounterText
struct UBasic_Menu_SmallWindowWithHeader_C_SetCounterText_Params
{
	struct FText*                                      InText;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.ExecuteUbergraph_Basic_Menu_SmallWindowWithHeader
struct UBasic_Menu_SmallWindowWithHeader_C_ExecuteUbergraph_Basic_Menu_SmallWindowWithHeader_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic_Menu_SmallWindowWithHeader.Basic_Menu_SmallWindowWithHeader_C.On Clicked__DelegateSignature
struct UBasic_Menu_SmallWindowWithHeader_C_On_Clicked__DelegateSignature_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
