#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function GM_Mining.GM_Mining_C.BndEvt__ObjectivesManager_K2Node_ComponentBoundEvent_0_DelegateEvent__DelegateSignature
struct AGM_Mining_C_BndEvt__ObjectivesManager_K2Node_ComponentBoundEvent_0_DelegateEvent__DelegateSignature_Params
{
};

// Function GM_Mining.GM_Mining_C.DonkeyButtonPressed
struct AGM_Mining_C_DonkeyButtonPressed_Params
{
};

// Function GM_Mining.GM_Mining_C.ExecuteUbergraph_GM_Mining
struct AGM_Mining_C_ExecuteUbergraph_GM_Mining_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
