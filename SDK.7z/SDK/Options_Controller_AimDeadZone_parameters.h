#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Options_Controller_AimDeadZone.Options_Controller_AimDeadZone_C.Construct
struct UOptions_Controller_AimDeadZone_C_Construct_Params
{
};

// Function Options_Controller_AimDeadZone.Options_Controller_AimDeadZone_C.UINeedsUpdate
struct UOptions_Controller_AimDeadZone_C_UINeedsUpdate_Params
{
};

// Function Options_Controller_AimDeadZone.Options_Controller_AimDeadZone_C.ShowOptions
struct UOptions_Controller_AimDeadZone_C_ShowOptions_Params
{
};

// Function Options_Controller_AimDeadZone.Options_Controller_AimDeadZone_C.BndEvt__Basic_Slider_K2Node_ComponentBoundEvent_2_OnValueChanged__DelegateSignature
struct UOptions_Controller_AimDeadZone_C_BndEvt__Basic_Slider_K2Node_ComponentBoundEvent_2_OnValueChanged__DelegateSignature_Params
{
	float*                                             Value;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Options_Controller_AimDeadZone.Options_Controller_AimDeadZone_C.ExecuteUbergraph_Options_Controller_AimDeadZone
struct UOptions_Controller_AimDeadZone_C_ExecuteUbergraph_Options_Controller_AimDeadZone_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
