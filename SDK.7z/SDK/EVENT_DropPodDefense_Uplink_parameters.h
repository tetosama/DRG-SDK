#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function EVENT_DropPodDefense_Uplink.EVENT_DropPodDefense_Uplink_C.EventSucceded
struct AEVENT_DropPodDefense_Uplink_C_EventSucceded_Params
{
};

// Function EVENT_DropPodDefense_Uplink.EVENT_DropPodDefense_Uplink_C.EventFailed
struct AEVENT_DropPodDefense_Uplink_C_EventFailed_Params
{
};

// Function EVENT_DropPodDefense_Uplink.EVENT_DropPodDefense_Uplink_C.ExecuteUbergraph_EVENT_DropPodDefense_Uplink
struct AEVENT_DropPodDefense_Uplink_C_ExecuteUbergraph_EVENT_DropPodDefense_Uplink_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
