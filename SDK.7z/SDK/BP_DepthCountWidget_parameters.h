#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_DepthCountWidget.BP_DepthCountWidget_C.UpdateDepthText
struct UBP_DepthCountWidget_C_UpdateDepthText_Params
{
};

// Function BP_DepthCountWidget.BP_DepthCountWidget_C.SetProgress
struct UBP_DepthCountWidget_C_SetProgress_Params
{
	float*                                             Progress;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BP_DepthCountWidget.BP_DepthCountWidget_C.Construct
struct UBP_DepthCountWidget_C_Construct_Params
{
};

// Function BP_DepthCountWidget.BP_DepthCountWidget_C.ExecuteUbergraph_BP_DepthCountWidget
struct UBP_DepthCountWidget_C_ExecuteUbergraph_BP_DepthCountWidget_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
