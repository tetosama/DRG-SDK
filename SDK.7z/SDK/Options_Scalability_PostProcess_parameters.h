#pragma once

#include "../SDK.h"

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Options_Scalability_PostProcess.Options_Scalability_PostProcess_C.Construct
struct UOptions_Scalability_PostProcess_C_Construct_Params
{
};

// Function Options_Scalability_PostProcess.Options_Scalability_PostProcess_C.UINeedsUpdate
struct UOptions_Scalability_PostProcess_C_UINeedsUpdate_Params
{
};

// Function Options_Scalability_PostProcess.Options_Scalability_PostProcess_C.ShowOptions
struct UOptions_Scalability_PostProcess_C_ShowOptions_Params
{
};

// Function Options_Scalability_PostProcess.Options_Scalability_PostProcess_C.BndEvt__Basic_OptionSwitcher_K2Node_ComponentBoundEvent_3_OnSelectionChanged__DelegateSignature
struct UOptions_Scalability_PostProcess_C_BndEvt__Basic_OptionSwitcher_K2Node_ComponentBoundEvent_3_OnSelectionChanged__DelegateSignature_Params
{
	struct FText*                                      Value;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm)
	int*                                               Index;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Options_Scalability_PostProcess.Options_Scalability_PostProcess_C.ExecuteUbergraph_Options_Scalability_PostProcess
struct UOptions_Scalability_PostProcess_C_ExecuteUbergraph_Options_Scalability_PostProcess_Params
{
	int*                                               EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
