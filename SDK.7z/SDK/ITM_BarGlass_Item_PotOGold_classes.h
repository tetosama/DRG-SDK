#pragma once

// Name: , Version: 1.0.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass ITM_BarGlass_Item_PotOGold.ITM_BarGlass_Item_PotOGold_C
// 0x0000 (0x04C8 - 0x04C8)
class AITM_BarGlass_Item_PotOGold_C : public AITM_BarGlass_Item_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass ITM_BarGlass_Item_PotOGold.ITM_BarGlass_Item_PotOGold_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
